import base64
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

try:
    import psutil
except ImportError:
    print("ОШИБКА: не установлен psutil.")
    print("Установи: pip install pywebview psutil")
    raise

import webview


APP_NAME = "McPilot"
APP_DIR = Path(__file__).resolve().parent
SETTINGS_FILE = APP_DIR / "settings.json"
ASSETS_DIR = APP_DIR / "assets"

IS_WINDOWS = os.name == "nt"
IS_MAC = platform.system() == "Darwin"
IS_LINUX = platform.system() == "Linux"

ASCII_BANNER = r"""
    ███╗   ███╗ ██████╗██████╗ ██╗██╗      ██████╗ ████████╗
    ████╗ ████║██╔════╝██╔══██╗██║██║     ██╔═══██╗╚══██╔══╝
    ██╔████╔██║██║     ██████╔╝██║██║     ██║   ██║   ██║
    ██║╚██╔╝██║██║     ██╔═══╝ ██║██║     ██║   ██║   ██║
    ██║ ╚═╝ ██║╚██████╗██║     ██║███████╗╚██████╔╝   ██║
    ╚═╝     ╚═╝ ╚═════╝╚═╝     ╚═╝╚══════╝ ╚═════╝    ╚═╝
"""


# -----------------------------------------------------------------------------
# Console / relaunch
# -----------------------------------------------------------------------------


def is_vscode_terminal():
    return bool(
        os.environ.get("VSCODE_INJECTION") == "1"
        or os.environ.get("TERM_PROGRAM") == "vscode"
        or os.environ.get("VSCODE_PID")
        or os.environ.get("VSCODE_CWD")
    )


def has_real_console():
    if not IS_WINDOWS:
        try:
            return sys.stdout.isatty()
        except Exception:
            return False
    try:
        import ctypes
        return ctypes.windll.kernel32.GetConsoleWindow() != 0
    except Exception:
        return True


def relaunch_in_new_console():
    """
    На Windows: если запущено НЕ из VSCode и НЕТ консоли (pythonw) —
    открывает новое cmd-окно со скриптом.
    """
    if not IS_WINDOWS:
        return False
    if os.environ.get("MCPILOT_CONSOLE") == "1":
        return False
    if is_vscode_terminal():
        return False
    if has_real_console():
        return False

    python = sys.executable
    if python.lower().endswith("pythonw.exe"):
        python = python[:-len("pythonw.exe")] + "python.exe"
    if not Path(python).exists():
        python = "python"

    script = str(Path(__file__).resolve())
    env = os.environ.copy()
    env["MCPILOT_CONSOLE"] = "1"

    try:
        subprocess.Popen(
            [python, script],
            creationflags=subprocess.CREATE_NEW_CONSOLE,
            env=env,
            cwd=str(APP_DIR),
            close_fds=True,
        )
        return True
    except Exception:
        return False


def setup_console():
    """Настраивает консоль: заголовок, кодировка, очистка, баннер."""
    if IS_WINDOWS:
        try:
            os.system(f"title {APP_NAME}")
        except Exception:
            pass
        try:
            os.system("chcp 65001 > nul")
        except Exception:
            pass

    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

    if not is_vscode_terminal():
        try:
            os.system("cls" if IS_WINDOWS else "clear")
        except Exception:
            pass


def show_banner():
    print(ASCII_BANNER)
    print(f"    {APP_NAME}  ·  Minecraft Server Manager")
    print(f"    Platform: {platform.system()} {platform.release()}")
    print()


# -----------------------------------------------------------------------------
# Backups dir
# -----------------------------------------------------------------------------


def _backups_dir():
    home = Path.home()
    candidates = [
        home / "Documents",
        home / "Документы",
        home / "Documentos",
        home / "Documenti",
        home / "文档",
        home / "Dokumente",
    ]
    for c in candidates:
        try:
            if c.exists() and c.is_dir():
                target = c / "McPilotBackups"
                target.mkdir(parents=True, exist_ok=True)
                return target
        except Exception:
            continue
    try:
        docs = home / "Documents"
        docs.mkdir(parents=True, exist_ok=True)
        target = docs / "McPilotBackups"
        target.mkdir(parents=True, exist_ok=True)
        return target
    except Exception:
        target = APP_DIR / "backups"
        target.mkdir(parents=True, exist_ok=True)
        return target


BACKUPS_DIR = _backups_dir()

MAX_LOG_LINES = 6000
MAX_FILE_SIZE = 20 * 1024 * 1024
MAX_BACKUPS_KEEP = 10

EDITABLE_EXTENSIONS = {
    ".properties", ".yml", ".yaml", ".json", ".txt", ".cfg", ".conf",
    ".ini", ".toml", ".xml", ".log", ".list", ".md", ".html", ".css",
    ".js", ".ts", ".java", ".py", ".bat", ".cmd", ".sh"
}

BACKUP_EXCLUDE_DIRS = {"logs", "crash-reports", "backups", ".git", "cache", "temp", "tmp", "__pycache__"}
BACKUP_EXCLUDE_FILES = {"session.lock", "usercache.json", "usernamecache.json"}
BACKUP_EXCLUDE_SUFFIX = {".log", ".log.gz", ".lock"}

DEFAULT_SETTINGS = {
    "lang": "ru",
    "theme": "emerald",
    "font": "system",
    "background_file": None,
    "gui_opacity": 0.72,
    "sound_enabled": True,
    "sound_volume": 0.7,
    "bat_file": None,
}


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------


def now_stamp():
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


def json_error(message):
    return {"success": False, "message": str(message)}


def safe_name(name):
    name = str(name or "").strip()
    if not name:
        raise ValueError("Имя не может быть пустым.")
    if name in {".", ".."}:
        raise ValueError("Недопустимое имя.")
    if any(ch in name for ch in '\\/:*?"<>|'):
        raise ValueError("Имя содержит недопустимые символы.")
    return name


def load_settings():
    if SETTINGS_FILE.exists():
        try:
            data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            merged = dict(DEFAULT_SETTINGS)
            merged.update(data)
            return merged
        except Exception:
            pass
    return dict(DEFAULT_SETTINGS)


def save_settings(settings):
    SETTINGS_FILE.write_text(
        json.dumps(settings, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def file_to_data_url(path: Path):
    ext = path.suffix.lower().lstrip(".")
    mime = {
        "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
        "gif": "image/gif", "webp": "image/webp",
    }.get(ext, "image/png")
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{data}"


def build_start_command(bat_path: Path):
    """Кроссплатформенная сборка команды запуска."""
    name = bat_path.name.lower()
    if name.endswith(".jar"):
        return ["java", "-jar", str(bat_path)]
    if name.endswith((".bat", ".cmd")):
        if IS_WINDOWS:
            return ["cmd.exe", "/d", "/c", str(bat_path)]
        if IS_LINUX or IS_MAC:
            return ["wine", "cmd", "/c", str(bat_path)]
        return ["cmd.exe", "/d", "/c", str(bat_path)]
    if name.endswith(".sh"):
        if IS_WINDOWS:
            return ["bash", str(bat_path)]
        return ["/bin/sh", str(bat_path)]
    return [str(bat_path)]


def ask_for_bat_file(lang="ru", current=None):
    if current:
        path = APP_DIR / current
        if path.exists():
            return current

    prompt = ("Введите имя вашего батника для запуска (например, start.bat, start.sh, server.jar): "
              if lang == "ru"
              else "Enter startup file name (e.g. start.bat, start.sh, server.jar): ")
    empty_msg = "Имя файла не может быть пустым." if lang == "ru" else "File name cannot be empty."
    outside_msg = "Файл должен находиться внутри папки сервера." if lang == "ru" \
        else "File must be inside the server folder."
    not_found = "Файл не найден" if lang == "ru" else "File not found"
    use_anyway = "Использовать это имя всё равно? [y/N]: " if lang == "ru" \
        else "Use this name anyway? [y/N]: "

    while True:
        bat_file = input(prompt).strip()
        if not bat_file:
            print(empty_msg)
            continue
        bat_file = bat_file.replace("/", os.sep)
        if Path(bat_file).is_absolute() or ".." in Path(bat_file).parts:
            print(outside_msg)
            continue
        path = APP_DIR / bat_file
        if not path.exists():
            print(f"{not_found}: {path}")
            if input(use_anyway).strip().lower() != "y":
                continue
        return bat_file


# -----------------------------------------------------------------------------
# Minecraft process manager
# -----------------------------------------------------------------------------


class MinecraftManager:
    def __init__(self, bat_file):
        self.bat_file = bat_file
        self.process = None
        self.state = "stopped"
        self.operation = None
        self.lock = threading.RLock()

        self.logs = []
        self.log_lock = threading.RLock()
        self.log_sequence = 0
        self._started_at = None

    def add_log(self, text):
        text = str(text).rstrip("\r\n")
        if not text:
            return
        with self.log_lock:
            self.log_sequence += 1
            self.logs.append((self.log_sequence, text))
            if len(self.logs) > MAX_LOG_LINES:
                self.logs = self.logs[-MAX_LOG_LINES:]

    def get_logs(self, after=0):
        try:
            after = int(after)
        except Exception:
            after = 0
        with self.log_lock:
            items = [line for seq, line in self.logs if seq > after]
            next_seq = self.log_sequence
        return {"items": items, "next": next_seq}

    def _process_tree_alive(self, pid):
        try:
            root = psutil.Process(pid)
            if root.is_running() and root.status() != psutil.STATUS_ZOMBIE:
                return True
            for child in root.children(recursive=True):
                try:
                    if child.is_running() and child.status() != psutil.STATUS_ZOMBIE:
                        return True
                except (psutil.Error, OSError):
                    continue
        except (psutil.Error, OSError):
            pass
        return False

    def _find_java_process(self, root_pid):
        candidates = []
        try:
            root = psutil.Process(root_pid)
            candidates.append(root)
            candidates.extend(root.children(recursive=True))
        except (psutil.Error, OSError):
            return None
        for proc in candidates:
            try:
                name = (proc.name() or "").lower()
                if name in {"java.exe", "javaw.exe", "java", "javaw"}:
                    return proc
            except (psutil.Error, OSError):
                continue
        return candidates[0] if candidates else None

    def _server_psutil_process(self):
        with self.lock:
            root = self.process
        if root is None:
            return None
        proc = self._find_java_process(root.pid)
        if proc is None:
            return None
        try:
            if not proc.is_running() or proc.status() == psutil.STATUS_ZOMBIE:
                return None
        except (psutil.Error, OSError):
            return None
        return proc

    def get_resources(self):
        proc = self._server_psutil_process()
        if proc is None:
            return {"cpu": 0.0, "ram": 0.0}
        try:
            cpu = float(proc.cpu_percent(interval=0.0))
            ram = float(proc.memory_info().rss / (1024 * 1024))
            return {"cpu": round(max(0.0, cpu), 1), "ram": round(max(0.0, ram), 1)}
        except (psutil.Error, OSError, ValueError):
            return {"cpu": 0.0, "ram": 0.0}

    def get_status(self):
        with self.lock:
            proc = self.process
            state = self.state
            operation = self.operation
        if proc is None:
            return {
                "running": False, "pid": None,
                "state": "stopped" if state != "starting" else state,
                "operation": operation,
            }
        if not self._process_tree_alive(proc.pid):
            with self.lock:
                if self.process is proc:
                    self.process = None
                    if self.operation is None:
                        self.state = "stopped"
            return {"running": False, "pid": None, "state": "stopped", "operation": operation}
        java_proc = self._server_psutil_process()
        return {
            "running": True,
            "pid": java_proc.pid if java_proc else proc.pid,
            "state": state,
            "operation": operation,
        }

    def _start_process(self):
        bat_path = APP_DIR / self.bat_file
        if not bat_path.exists():
            return json_error(f"Startup file not found: {bat_path.name}")
        with self.lock:
            if self.process is not None and self._process_tree_alive(self.process.pid):
                return json_error("Server is already running.")
        flags = 0
        if IS_WINDOWS:
            flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        try:
            cmd = build_start_command(bat_path)
            proc = subprocess.Popen(
                cmd,
                cwd=str(APP_DIR),
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                creationflags=flags,
            )
        except FileNotFoundError as exc:
            return json_error(f"Command not found: {exc}")
        except Exception as exc:
            return json_error(f"Start error: {exc}")
        with self.lock:
            self.process = proc
            self.state = "starting"
            self._started_at = time.monotonic()
        self.add_log("")
        self.add_log("─" * 68)
        self.add_log(f"Starting Minecraft server: {bat_path.name}")
        self.add_log(f"Command: {' '.join(cmd)}")
        self.add_log(f"Session: {now_stamp()}")
        self.add_log("─" * 68)
        threading.Thread(target=self._read_output, args=(proc,), daemon=True).start()
        threading.Thread(target=self._watch_start, args=(proc,), daemon=True).start()
        return {"success": True, "message": "Server is starting."}

    def start(self):
        with self.lock:
            if self.operation:
                return json_error(f"Operation already in progress: {self.operation}")
        return self._start_process()

    def _watch_start(self, proc):
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            with self.lock:
                if self.process is not proc:
                    return
            if proc.poll() is not None:
                return
            if self._find_java_process(proc.pid) is not None:
                with self.lock:
                    if self.process is proc and self.state == "starting":
                        self.state = "running"
                return
            time.sleep(0.25)
        with self.lock:
            if self.process is proc and self.state == "starting":
                self.state = "running"

    def _read_output(self, proc):
        try:
            if proc.stdout is not None:
                for line in iter(proc.stdout.readline, ""):
                    if line == "":
                        break
                    self.add_log(line)
        except Exception as exc:
            self.add_log(f"[Manager] Console read error: {exc}")
        finally:
            try:
                if proc.stdout:
                    proc.stdout.close()
            except Exception:
                pass
            code = proc.poll()
            with self.lock:
                if self.process is proc and proc.poll() is not None:
                    self.process = None
                    if self.operation is None:
                        self.state = "stopped"
            self.add_log(f"[Manager] Process finished. Code: {code}")

    def send_command(self, command):
        command = str(command or "").strip()
        if not command:
            return json_error("Empty command.")
        with self.lock:
            proc = self.process
        if proc is None or proc.poll() is not None:
            return json_error("Server is not running.")
        try:
            if proc.stdin is None:
                return json_error("stdin is not available.")
            proc.stdin.write(command + "\n")
            proc.stdin.flush()
            return {"success": True, "message": ""}
        except Exception as exc:
            return json_error(str(exc))

    def _kill_tree(self, pid):
        try:
            root = psutil.Process(pid)
        except (psutil.Error, OSError):
            return
        processes = []
        try:
            processes = root.children(recursive=True)
        except (psutil.Error, OSError):
            pass
        processes.append(root)
        for child in processes:
            try:
                child.terminate()
            except (psutil.Error, OSError):
                pass
        gone, alive = psutil.wait_procs(processes, timeout=2)
        for child in alive:
            try:
                child.kill()
            except (psutil.Error, OSError):
                pass
        if IS_WINDOWS:
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(pid), "/T", "/F"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=4, check=False,
                )
            except Exception:
                pass

    def _stop_and_wait(self, proc, graceful_timeout=15):
        self.add_log("")
        self.add_log("[Manager] Sending stop command...")
        try:
            if proc.stdin:
                proc.stdin.write("stop\n")
                proc.stdin.flush()
        except Exception as exc:
            self.add_log(f"[Manager] Failed to send stop: {exc}")
        deadline = time.monotonic() + graceful_timeout
        while time.monotonic() < deadline:
            if not self._process_tree_alive(proc.pid):
                self.add_log("[Manager] Server stopped gracefully.")
                return True
            time.sleep(0.15)
        self.add_log("[Manager] Graceful timeout. Forcing kill...")
        self._kill_tree(proc.pid)
        deadline = time.monotonic() + 4
        while time.monotonic() < deadline:
            if not self._process_tree_alive(proc.pid):
                break
            time.sleep(0.15)
        return not self._process_tree_alive(proc.pid)

    def stop(self):
        with self.lock:
            if self.operation:
                return json_error(f"Operation already in progress: {self.operation}")
            proc = self.process
            if proc is None or not self._process_tree_alive(proc.pid):
                self.process = None
                self.state = "stopped"
                return {"success": True, "message": "Server is already stopped."}
            self.operation = "stop"
            self.state = "stopping"
        threading.Thread(target=self._stop_worker, args=(proc,), daemon=True).start()
        return {"success": True, "message": "Server is stopping."}

    def _stop_worker(self, proc):
        ok = self._stop_and_wait(proc)
        with self.lock:
            if self.process is proc:
                self.process = None
            self.state = "stopped"
            self.operation = None
        self.add_log("[Manager] Server stopped." if ok else "[Manager] Could not confirm termination.")

    def restart(self):
        with self.lock:
            if self.operation:
                return json_error(f"Operation already in progress: {self.operation}")
            proc = self.process
            running = proc is not None and self._process_tree_alive(proc.pid)
            self.operation = "restart"
            self.state = "restarting" if running else "starting"
        threading.Thread(target=self._restart_worker, args=(proc, running), daemon=True).start()
        return {"success": True, "message": "Restart started."}

    def _restart_worker(self, proc, running):
        try:
            if running and proc is not None:
                self._stop_and_wait(proc, graceful_timeout=10)
            with self.lock:
                if self.process is proc:
                    self.process = None
                self.state = "starting"
            result = self._start_process()
            if not result.get("success"):
                self.add_log("[Manager] Restart failed: " + result.get("message", "error"))
                with self.lock:
                    self.state = "stopped"
        finally:
            with self.lock:
                self.operation = None

    def shutdown(self):
        with self.lock:
            proc = self.process
        if proc is not None and self._process_tree_alive(proc.pid):
            try:
                self._stop_and_wait(proc, graceful_timeout=8)
            except Exception:
                self._kill_tree(proc.pid)
        with self.lock:
            self.process = None
            self.operation = None
            self.state = "stopped"


# -----------------------------------------------------------------------------
# File manager
# -----------------------------------------------------------------------------


class FileManager:
    def __init__(self, root):
        self.root = Path(root).resolve()

    def safe_path(self, relative_path=""):
        relative_path = str(relative_path or "").replace("\\", "/")
        candidate = (self.root / relative_path).resolve()
        try:
            candidate.relative_to(self.root)
        except ValueError:
            raise PermissionError("Access outside server folder is forbidden.")
        return candidate

    def relative(self, path):
        rel = path.resolve().relative_to(self.root).as_posix()
        return "" if rel == "." else rel

    def _file_icon(self, path, is_dir):
        if is_dir:
            return "folder"
        ext = path.suffix.lower()
        return {
            ".jar": "java", ".java": "java", ".json": "json", ".yml": "yaml", ".yaml": "yaml",
            ".properties": "config", ".txt": "text", ".log": "log", ".bat": "terminal", ".cmd": "terminal",
            ".sh": "terminal", ".js": "js", ".css": "css", ".html": "html", ".zip": "archive",
            ".png": "image", ".jpg": "image", ".jpeg": "image", ".webp": "image", ".gif": "image",
            ".db": "database", ".db3": "database"
        }.get(ext, "file")

    def list_directory(self, relative_path=""):
        path = self.safe_path(relative_path)
        if not path.exists() or not path.is_dir():
            raise FileNotFoundError("Folder not found.")
        items = []
        for item in path.iterdir():
            try:
                is_dir = item.is_dir()
                stat = item.stat()
                items.append({
                    "name": item.name,
                    "path": self.relative(item),
                    "type": "directory" if is_dir else "file",
                    "size": 0 if is_dir else stat.st_size,
                    "editable": (not is_dir and item.suffix.lower() in EDITABLE_EXTENSIONS),
                    "icon": self._file_icon(item, is_dir),
                })
            except OSError:
                continue
        items.sort(key=lambda x: (x["type"] != "directory", x["name"].lower()))
        current = self.relative(path)
        parent = None if not current else self.relative(path.parent)
        return {"path": current, "parent": parent, "items": items}

    def read_file(self, relative_path):
        path = self.safe_path(relative_path)
        if not path.is_file():
            raise FileNotFoundError("File not found.")
        if path.suffix.lower() not in EDITABLE_EXTENSIONS:
            raise PermissionError("This file type cannot be opened in the editor.")
        if path.stat().st_size > MAX_FILE_SIZE:
            raise ValueError(f"File too large. Limit: {MAX_FILE_SIZE // (1024 * 1024)} MB.")
        return {"path": self.relative(path), "content": path.read_text(encoding="utf-8", errors="replace")}

    def write_file(self, relative_path, content):
        path = self.safe_path(relative_path)
        if path.suffix.lower() not in EDITABLE_EXTENSIONS:
            raise PermissionError("This file type cannot be edited.")
        if len(content.encode("utf-8")) > MAX_FILE_SIZE:
            raise ValueError(f"File too large. Limit: {MAX_FILE_SIZE // (1024 * 1024)} MB.")
        path.write_text(content, encoding="utf-8", newline="")
        return {"success": True, "message": "File saved."}

    def create_file(self, directory, name):
        name = safe_name(name)
        path = self.safe_path(directory) / name
        if path.exists():
            raise FileExistsError("Item with this name already exists.")
        path.touch()
        return {"success": True, "message": f"Created file: {name}"}

    def create_folder(self, directory, name):
        name = safe_name(name)
        path = self.safe_path(directory) / name
        if path.exists():
            raise FileExistsError("Item with this name already exists.")
        path.mkdir()
        return {"success": True, "message": f"Created folder: {name}"}

    def delete(self, relative_path):
        path = self.safe_path(relative_path)
        if path == self.root:
            raise PermissionError("Cannot delete server root.")
        if not path.exists():
            raise FileNotFoundError("Item not found.")
        if path.is_dir():
            shutil.rmtree(path)
        else:
            path.unlink()
        return {"success": True, "message": "Item deleted."}

    def rename(self, relative_path, new_name):
        new_name = safe_name(new_name)
        path = self.safe_path(relative_path)
        if path == self.root:
            raise PermissionError("Cannot rename server root.")
        if not path.exists():
            raise FileNotFoundError("Item not found.")
        target = path.parent / new_name
        if target.exists():
            raise FileExistsError("Item with this name already exists.")
        path.rename(target)
        return {"success": True, "message": "Renamed."}

    def upload_from_dialog(self, directory):
        window = webview.active_window()
        if window is None:
            return json_error("Window is not available.")
        selected = window.create_file_dialog(
            webview.FileDialog.OPEN,
            allow_multiple=True,
            file_types=("All files (*.*)",),
        )
        if not selected:
            return {"success": False, "cancelled": True, "message": "Cancelled."}
        destination = self.safe_path(directory)
        copied = 0
        for source_text in selected:
            source = Path(source_text)
            if not source.is_file():
                continue
            shutil.copy2(source, destination / source.name)
            copied += 1
        return {"success": True, "message": f"Uploaded files: {copied}"}

    def download_to_dialog(self, relative_path):
        source = self.safe_path(relative_path)
        if not source.exists():
            raise FileNotFoundError("Item not found.")
        if source.is_file():
            window = webview.active_window()
            if window is None:
                return json_error("Window is not available.")
            result = window.create_file_dialog(
                webview.FileDialog.SAVE,
                directory=str(APP_DIR),
                save_filename=source.name,
            )
            if not result:
                return {"success": False, "cancelled": True, "message": "Cancelled."}
            shutil.copy2(source, Path(result[0]))
            return {"success": True, "message": "File saved to PC."}
        with tempfile.TemporaryDirectory(prefix="mcpilot_download_") as temp_dir:
            archive = Path(temp_dir) / f"{source.name}.zip"
            with ZipFile(archive, "w", ZIP_DEFLATED) as zf:
                for file_path in source.rglob("*"):
                    if file_path.is_file():
                        zf.write(file_path, file_path.relative_to(source.parent))
            window = webview.active_window()
            if window is None:
                return json_error("Window is not available.")
            result = window.create_file_dialog(
                webview.FileDialog.SAVE,
                directory=str(APP_DIR),
                save_filename=archive.name,
            )
            if not result:
                return {"success": False, "cancelled": True, "message": "Cancelled."}
            shutil.copy2(archive, Path(result[0]))
            return {"success": True, "message": "Folder downloaded as ZIP."}

    def _should_skip(self, item):
        if item.is_dir():
            if item.name in BACKUP_EXCLUDE_DIRS:
                return True
        else:
            if item.name in BACKUP_EXCLUDE_FILES:
                return True
            if item.suffix.lower() in BACKUP_EXCLUDE_SUFFIX:
                return True
        return False

    def _cleanup_old_backups(self):
        try:
            files = sorted(
                BACKUPS_DIR.glob("*.zip"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            for old in files[MAX_BACKUPS_KEEP:]:
                try:
                    old.unlink()
                except OSError:
                    pass
        except Exception:
            pass

    def backup(self, relative_path=""):
        source = self.safe_path(relative_path)
        if not source.exists():
            raise FileNotFoundError("Folder for backup not found.")
        BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
        label = source.name if source != self.root else "server"
        archive = BACKUPS_DIR / f"{label}_{now_stamp()}.zip"
        with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=9) as zf:
            if source.is_file():
                zf.write(source, source.name)
            else:
                base = source.parent
                for item in source.rglob("*"):
                    if not item.is_file():
                        continue
                    try:
                        rel_parts = item.relative_to(source).parts
                    except ValueError:
                        continue
                    skip = False
                    for part in rel_parts[:-1]:
                        if part in BACKUP_EXCLUDE_DIRS:
                            skip = True
                            break
                    if skip:
                        continue
                    if self._should_skip(item):
                        continue
                    arcname = item.relative_to(base).as_posix()
                    try:
                        zf.write(item, arcname)
                    except OSError:
                        continue
        self._cleanup_old_backups()
        size_mb = archive.stat().st_size / (1024 * 1024)
        return {
            "success": True,
            "message": f"Backup created: {archive.name} ({size_mb:.1f} MB)",
            "path": str(archive),
        }


# -----------------------------------------------------------------------------
# API
# -----------------------------------------------------------------------------


class API:
    def __init__(self, manager, files):
        self.manager = manager
        self.files = files

    def status(self): return self.manager.get_status()
    def get_resources(self): return self.manager.get_resources()
    def logs(self, after=0): return self.manager.get_logs(after)
    def start_server(self): return self.manager.start()
    def stop_server(self): return self.manager.stop()
    def restart_server(self): return self.manager.restart()
    def send_command(self, command): return self.manager.send_command(command)

    def list_files(self, path=""):
        try: return {"success": True, "data": self.files.list_directory(path)}
        except Exception as exc: return json_error(exc)

    def read_file(self, path):
        try: return {"success": True, "data": self.files.read_file(path)}
        except Exception as exc: return json_error(exc)

    def save_file(self, path, content):
        try: return self.files.write_file(path, content)
        except Exception as exc: return json_error(exc)

    def create_file(self, directory, name):
        try: return self.files.create_file(directory, name)
        except Exception as exc: return json_error(exc)

    def create_folder(self, directory, name):
        try: return self.files.create_folder(directory, name)
        except Exception as exc: return json_error(exc)

    def delete(self, path):
        try: return self.files.delete(path)
        except Exception as exc: return json_error(exc)

    def rename(self, path, name):
        try: return self.files.rename(path, name)
        except Exception as exc: return json_error(exc)

    def upload(self, directory):
        try: return self.files.upload_from_dialog(directory)
        except Exception as exc: return json_error(exc)

    def download(self, path):
        try: return self.files.download_to_dialog(path)
        except Exception as exc: return json_error(exc)

    def backup(self, path=""):
        try: return self.files.backup(path)
        except Exception as exc: return json_error(exc)

    def get_bat_file(self):
        return {"bat_file": self.manager.bat_file}

    def set_bat_file(self, name):
        try:
            name = str(name or "").strip().replace("/", os.sep)
            if not name:
                return json_error("Name cannot be empty.")
            if Path(name).is_absolute() or ".." in Path(name).parts:
                return json_error("Must be inside server folder.")
            path = APP_DIR / name
            if not path.exists():
                return json_error(f"File not found: {name}")
            with self.manager.lock:
                if self.manager.process is not None and self.manager._process_tree_alive(self.manager.process.pid):
                    return json_error("Cannot change startup file while server is running.")
                self.manager.bat_file = name
            s = load_settings()
            s["bat_file"] = name
            save_settings(s)
            return {"success": True, "bat_file": name}
        except Exception as exc:
            return json_error(exc)

    def pick_bat_file(self):
        window = webview.active_window()
        if window is None:
            return json_error("Window not available.")
        selected = window.create_file_dialog(
            webview.FileDialog.OPEN,
            directory=str(APP_DIR),
            file_types=(
                "Startup files (*.bat;*.cmd;*.sh;*.jar)",
                "Batch (*.bat;*.cmd)",
                "Shell (*.sh)",
                "Java JAR (*.jar)",
                "All files (*.*)",
            ),
        )
        if not selected:
            return {"success": False, "cancelled": True, "message": "Cancelled."}
        src = Path(selected[0])
        try:
            rel = src.resolve().relative_to(APP_DIR).as_posix()
        except ValueError:
            return json_error("File must be inside server folder.")
        if not src.exists():
            return json_error("File not found.")
        with self.manager.lock:
            if self.manager.process is not None and self.manager._process_tree_alive(self.manager.process.pid):
                return json_error("Cannot change startup file while server is running.")
            self.manager.bat_file = rel
        s = load_settings()
        s["bat_file"] = rel
        save_settings(s)
        return {"success": True, "bat_file": rel}

    def get_settings(self):
        s = load_settings()
        bg_url = None
        if s.get("background_file"):
            p = ASSETS_DIR / s["background_file"]
            if p.exists():
                try:
                    bg_url = file_to_data_url(p)
                except Exception:
                    bg_url = None
        return {
            "success": True,
            "settings": s,
            "background": bg_url,
            "platform": {
                "os": "windows" if IS_WINDOWS else ("mac" if IS_MAC else "linux"),
                "name": platform.system(),
                "version": platform.version(),
            },
        }

    def update_settings(self, patch):
        try:
            s = load_settings()
            if isinstance(patch, dict):
                s.update(patch)
            save_settings(s)
            return {"success": True, "settings": s}
        except Exception as exc:
            return json_error(exc)

    def pick_background(self):
        window = webview.active_window()
        if window is None:
            return json_error("Window not available.")
        selected = window.create_file_dialog(
            webview.FileDialog.OPEN,
            file_types=("Images (*.png;*.jpg;*.jpeg;*.gif;*.webp)",),
        )
        if not selected:
            return {"success": False, "cancelled": True, "message": "Cancelled."}
        src = Path(selected[0])
        if not src.is_file():
            return json_error("File not found.")
        ext = src.suffix.lower()
        if ext not in {".png", ".jpg", ".jpeg", ".gif", ".webp"}:
            return json_error("Unsupported format.")
        try:
            ASSETS_DIR.mkdir(parents=True, exist_ok=True)
            for old in ASSETS_DIR.glob("background.*"):
                try:
                    old.unlink()
                except OSError:
                    pass
            dst = ASSETS_DIR / f"background{ext}"
            shutil.copy2(src, dst)
            s = load_settings()
            s["background_file"] = dst.name
            save_settings(s)
            return {"success": True, "data_url": file_to_data_url(dst), "settings": s}
        except Exception as exc:
            return json_error(exc)

    def reset_background(self):
        try:
            if ASSETS_DIR.exists():
                for old in ASSETS_DIR.glob("background.*"):
                    try:
                        old.unlink()
                    except OSError:
                        pass
            s = load_settings()
            s["background_file"] = None
            save_settings(s)
            return {"success": True, "settings": s}
        except Exception as exc:
            return json_error(exc)

    def minimize_window(self):
        w = webview.active_window()
        if w is None: return {"success": False}
        w.minimize()
        return {"success": True}

    def maximize_window(self):
        w = webview.active_window()
        if w is None: return {"success": False}
        if getattr(w, "maximized", False): w.restore()
        else: w.maximize()
        return {"success": True}

    def toggle_fullscreen(self):
        w = webview.active_window()
        if w is None: return {"success": False}
        try:
            w.toggle_fullscreen()
            return {"success": True}
        except Exception as exc:
            return json_error(exc)

    def close_window(self):
        w = webview.active_window()
        if w is None: return {"success": False}
        w.destroy()
        return {"success": True}


# -----------------------------------------------------------------------------
# HTML
# -----------------------------------------------------------------------------


HTML = r'''
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>McPilot</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&family=Fira+Code:wght@400;500&family=Roboto:wght@400;500;700&family=Source+Serif+4:wght@400;600&display=swap" rel="stylesheet">
<style>
:root{
  --bg:#080b11;
  --surface-rgb:20,27,39;
  --panel-opacity:0.72;
  --line:rgba(255,255,255,.07);
  --line-2:rgba(255,255,255,.12);
  --text:#e9eff3;
  --muted:#8494a0;
  --muted-2:#5a6a76;
  --green:#5ee89a;
  --blue:#79a9ff;
  --red:#ff7373;
  --yellow:#ffd166;
  --accent-rgb:94,232,154;
  --glow-1:#1a6fff;
  --glow-2:#00d890;
  --font-ui:'Inter',ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
  --font-mono:'JetBrains Mono',"Cascadia Mono",ui-monospace,Consolas,monospace;
  --shadow-lg:0 24px 60px rgba(0,0,0,.5);
  --radius-lg:18px;
  --radius-md:12px;
  --radius-sm:9px;
}
*{box-sizing:border-box;min-width:0}
html,body{margin:0;width:100%;height:100%;overflow:hidden;background:var(--bg);color:var(--text);font-family:var(--font-ui);-webkit-font-smoothing:antialiased;background-size:cover;background-position:center;background-repeat:no-repeat;background-attachment:fixed;transition:background-color .3s}
body.bg-custom{background-color:#050810}
.bg-overlay{position:fixed;inset:0;z-index:-1;pointer-events:none;background:transparent;transition:background .3s,backdrop-filter .3s}
body.bg-custom .bg-overlay{background:rgba(6,9,15,.72);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)}
body:before,body:after{content:"";position:fixed;z-index:-2;border-radius:50%;filter:blur(120px);opacity:.20;pointer-events:none;transition:background .35s}
body:before{width:520px;height:520px;left:-180px;top:-160px;background:var(--glow-1);animation:floatA 18s ease-in-out infinite}
body:after{width:560px;height:560px;right:-220px;bottom:-220px;background:var(--glow-2);animation:floatB 22s ease-in-out infinite}
@keyframes floatA{0%,100%{transform:translate(0,0)}50%{transform:translate(60px,40px)}}
@keyframes floatB{0%,100%{transform:translate(0,0)}50%{transform:translate(-70px,-50px)}}
body.bg-custom:before,body.bg-custom:after{opacity:.06}
button,input,textarea,select{font:inherit;color:inherit}
button{cursor:pointer;border:0;background:none;position:relative;overflow:hidden}
.ripple{position:absolute;border-radius:50%;background:rgba(255,255,255,.35);transform:scale(0);animation:rippleAnim .6s ease-out;pointer-events:none}
@keyframes rippleAnim{to{transform:scale(4);opacity:0}}
.app{height:100%;display:flex;flex-direction:column;padding:12px;gap:10px;animation:appIn .5s ease}
@keyframes appIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
.glass{background:rgba(var(--surface-rgb),var(--panel-opacity));border:1px solid var(--line);box-shadow:var(--shadow-lg);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);transition:background .25s,border-color .25s,box-shadow .25s}

.header{display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:var(--radius-lg);flex-wrap:wrap}
.traffic{display:flex;gap:8px;align-items:center;padding-right:10px;flex-shrink:0}
.tl{width:12px;height:12px;border-radius:50%;border:none;cursor:pointer;position:relative;transition:.18s;display:grid;place-items:center;padding:0;box-shadow:inset 0 0 0 .5px rgba(0,0,0,.2);overflow:visible}
.tl.close{background:#ff5f57}.tl.min{background:#febc2e}.tl.max{background:#28c840}
.tl:hover{filter:brightness(1.15);transform:scale(1.08)}
.tl:active{filter:brightness(.9);transform:scale(.96)}
.tl svg{width:7px;height:7px;opacity:0;transition:.12s;color:rgba(0,0,0,.6);pointer-events:none}
.traffic:hover .tl svg{opacity:1}

.brand{display:flex;flex-direction:column;gap:2px;padding-right:14px;border-right:1px solid var(--line);min-width:0;user-select:none;cursor:default}
.title{font-size:14px;font-weight:700;white-space:nowrap;background:linear-gradient(135deg,#fff 0%,var(--green) 50%,#fff 100%);background-size:200% auto;-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;animation:shimmer 4s linear infinite}
@keyframes shimmer{to{background-position:200% center}}
.subtitle{font-size:11px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:230px}
.drag-zone{width:24px;height:32px;flex-shrink:0;user-select:none}

.server-pill{display:flex;align-items:center;gap:9px;padding:8px 12px;border-radius:999px;background:rgba(0,0,0,.28);border:1px solid var(--line);white-space:nowrap;transition:.25s}
.dot{width:8px;height:8px;border-radius:50%;background:#5a6a76;transition:.25s;position:relative}
.server-pill.running{border-color:rgba(var(--accent-rgb),.24);background:rgba(var(--accent-rgb),.06)}
.server-pill.running .dot{background:var(--green)}
.server-pill.running .dot:after{content:"";position:absolute;inset:-4px;border-radius:50%;border:1px solid rgba(var(--accent-rgb),.5);animation:pulse 2s ease-out infinite}
@keyframes pulse{0%{transform:scale(.8);opacity:1}100%{transform:scale(2.2);opacity:0}}
.server-pill.starting .dot,.server-pill.restarting .dot{background:var(--yellow);animation:blink 1s ease-in-out infinite}
.server-pill.stopping .dot{background:var(--red);animation:blink 1s ease-in-out infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.4}}
.server-text{font-size:12px;color:#d7e1e6}
.metrics{display:flex;gap:6px}
.metric{min-width:78px;padding:7px 10px;border-radius:var(--radius-md);background:rgba(0,0,0,.25);border:1px solid var(--line);transition:.2s}
.metric:hover{border-color:var(--line-2)}
.metric-label{font-size:9px;text-transform:uppercase;letter-spacing:.12em;color:var(--muted-2);font-weight:600}
.metric-value{font-size:12px;font-weight:700;margin-top:3px;font-variant-numeric:tabular-nums}
.spacer{flex:1;min-width:0}
.actions{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.btn{height:34px;padding:0 13px;border-radius:var(--radius-sm);border:1px solid var(--line);background:rgba(255,255,255,.03);font-size:12px;font-weight:500;transition:.2s;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;position:relative;overflow:hidden}
.btn:hover:not(:disabled){background:rgba(255,255,255,.08);border-color:var(--line-2);transform:translateY(-1px)}
.btn:active:not(:disabled){transform:translateY(0)}
.btn:disabled{opacity:.35;cursor:default}
.btn.primary{background:rgba(var(--accent-rgb),.14);border-color:rgba(var(--accent-rgb),.24);color:#c1ffdd}
.btn.primary:hover:not(:disabled){background:rgba(var(--accent-rgb),.22);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.06)}
.btn.danger{background:rgba(255,115,115,.1);border-color:rgba(255,115,115,.24);color:#ffc1c1}
.btn.danger:hover:not(:disabled){background:rgba(255,115,115,.18)}
.btn.backup{background:rgba(121,169,255,.1);border-color:rgba(121,169,255,.24);color:#cddaff}
.btn.backup:hover:not(:disabled){background:rgba(121,169,255,.18)}
.gear{width:34px;height:34px;border-radius:var(--radius-sm);background:rgba(255,255,255,.03);border:1px solid var(--line);display:grid;place-items:center;color:#a4b2bc;transition:.25s}
.gear:hover{background:rgba(255,255,255,.09);color:#fff;transform:rotate(60deg)}
.gear svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}

.main{flex:1;min-height:0;display:grid;grid-template-columns:minmax(0,1fr) 380px;gap:10px;transition:.2s}

.panel{min-height:0;display:flex;flex-direction:column;border-radius:var(--radius-lg);overflow:hidden;animation:panelIn .45s ease backwards}
.panel:nth-child(1){animation-delay:.05s}
.panel:nth-child(2){animation-delay:.1s}
@keyframes panelIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
.panel-head{min-height:46px;display:flex;align-items:center;gap:10px;padding:6px 12px;border-bottom:1px solid var(--line);background:rgba(255,255,255,.02)}
.panel-title{font-size:11px;text-transform:uppercase;letter-spacing:.14em;color:#a2b0bb;font-weight:700}
.badge{font-size:10px;padding:3px 8px;border-radius:999px;background:rgba(255,255,255,.06);color:#b8c4ce;border:1px solid var(--line);font-weight:600;transition:.2s}
.badge.running{color:#aaffcc;border-color:rgba(var(--accent-rgb),.4);background:rgba(var(--accent-rgb),.1)}

.console{flex:1;min-height:0;overflow:auto;padding:14px 16px;background:rgba(2,6,12,.35);font-family:var(--font-mono);font-size:12.5px;line-height:1.7;user-select:text;cursor:text}
.console::-webkit-scrollbar,.file-list::-webkit-scrollbar{width:10px;height:10px}
.console::-webkit-scrollbar-thumb,.file-list::-webkit-scrollbar-thumb{background:rgba(255,255,255,.08);border-radius:8px;border:2px solid transparent;background-clip:padding-box}
.console::-webkit-scrollbar-thumb:hover,.file-list::-webkit-scrollbar-thumb:hover{background:rgba(255,255,255,.16);background-clip:padding-box}
.log{white-space:pre-wrap;word-break:break-word;color:#c0cdd4;animation:logIn .18s ease}
@keyframes logIn{from{opacity:0;transform:translateX(-4px)}to{opacity:1;transform:translateX(0)}}
.log.dim{color:#6e7f89}
.log.error{color:#ff8a8a}
.log.warn{color:#ffd97a}
.log.ok{color:#8fe9b0}
.log.info{color:#9ec7ff}
.command{min-height:54px;display:flex;align-items:center;gap:8px;padding:8px 10px;border-top:1px solid var(--line);background:rgba(255,255,255,.02)}
.prompt{color:var(--green);font-weight:700;font-family:var(--font-mono)}
.command input,.editor textarea{outline:none;border:1px solid var(--line);background:rgba(0,0,0,.28);color:var(--text);border-radius:var(--radius-sm);transition:.2s;user-select:text}
.command input{height:36px;flex:1;padding:0 12px;font-size:12.5px}
.command input:focus,.editor textarea:focus{border-color:rgba(var(--accent-rgb),.4);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.08)}
.send{width:38px;height:36px;border-radius:var(--radius-sm);background:rgba(var(--accent-rgb),.10);border:1px solid rgba(var(--accent-rgb),.24);color:var(--green);display:grid;place-items:center;transition:.2s}
.send:hover{background:rgba(var(--accent-rgb),.20);border-color:rgba(var(--accent-rgb),.4);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.08)}
.send:active{transform:scale(.94)}
.send svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}

.files{min-width:0}
.file-toolbar{display:flex;gap:5px;padding:8px 10px;border-bottom:1px solid var(--line);flex-wrap:wrap}
.tool{height:30px;padding:0 10px;border-radius:var(--radius-sm);background:rgba(255,255,255,.03);border:1px solid var(--line);color:#b8c4ce;font-size:11px;font-weight:500;transition:.2s;display:inline-flex;align-items:center;gap:5px;white-space:nowrap}
.tool:hover{background:rgba(255,255,255,.08);color:#fff;transform:translateY(-1px)}
.tool.red{color:#ffb1b1;border-color:rgba(255,115,115,.18)}
.tool.red:hover{background:rgba(255,115,115,.14)}
.breadcrumbs{display:flex;align-items:center;gap:2px;min-height:36px;padding:6px 10px;border-bottom:1px solid var(--line);overflow-x:auto;white-space:nowrap}
.breadcrumbs::-webkit-scrollbar{height:6px}
.breadcrumbs::-webkit-scrollbar-thumb{background:rgba(255,255,255,.08);border-radius:4px}
.crumb{background:transparent;color:#a6b4be;padding:4px 7px;border-radius:7px;font-size:11px;transition:.15s}
.crumb:hover{background:rgba(255,255,255,.07);color:#fff}
.sep{color:#4a5860;font-size:10px;padding:0 1px}
.file-list{flex:1;min-height:0;overflow:auto;padding:6px}
.empty{padding:40px 16px;text-align:center;color:var(--muted-2);font-size:11.5px}
.file-row{display:grid;grid-template-columns:26px 1fr auto auto;align-items:center;gap:8px;padding:8px 9px;border-radius:var(--radius-md);border:1px solid transparent;background:transparent;transition:.15s;user-select:none;cursor:pointer;animation:rowIn .22s ease backwards}
@keyframes rowIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
.file-row:hover{background:rgba(255,255,255,.045);border-color:rgba(255,255,255,.05);transform:translateX(2px)}
.file-row.selected{background:rgba(var(--accent-rgb),.07);border-color:rgba(var(--accent-rgb),.18)}
.file-icon{width:20px;height:20px;display:grid;place-items:center;color:#8fa4b3;transition:.15s}
.file-row:hover .file-icon{color:#c1ccd4}
.file-icon svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.file-icon.icon-folder{color:#79a9ff}.file-icon.icon-java{color:#ff9a5c}
.file-icon.icon-json{color:#ffd166}.file-icon.icon-yaml{color:#c792ea}
.file-icon.icon-terminal{color:#8fe9b0}.file-icon.icon-archive{color:#c792ea}
.file-icon.icon-image{color:#8fe9b0}.file-icon.icon-database{color:#79a9ff}
.file-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12.5px}
.file-meta{font-size:10.5px;color:#67767f;font-variant-numeric:tabular-nums}
.row-actions{display:flex;gap:3px;opacity:0;transition:.2s}
.file-row:hover .row-actions,.file-row.selected .row-actions{opacity:1}
.mini{width:26px;height:26px;border-radius:7px;background:rgba(255,255,255,.05);border:1px solid var(--line);font-size:11px;display:grid;place-items:center;transition:.15s}
.mini:hover{background:rgba(255,255,255,.12);color:#fff;transform:scale(1.06)}

.context{position:fixed;z-index:50;display:none;width:190px;padding:5px;border-radius:var(--radius-md);background:rgba(var(--surface-rgb),.97);border:1px solid var(--line-2);box-shadow:var(--shadow-lg);backdrop-filter:blur(18px);animation:ctxIn .14s ease}
@keyframes ctxIn{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}
.context button{display:block;width:100%;padding:9px 10px;text-align:left;border-radius:8px;background:transparent;color:#cfd9dd;font-size:11.5px;transition:.12s}
.context button:hover{background:rgba(255,255,255,.08);color:#fff;padding-left:12px}
.context button.danger{color:#ffb1b1}
.context button.danger:hover{background:rgba(255,115,115,.14)}

.overlay{position:fixed;inset:0;z-index:40;display:none;place-items:center;background:rgba(0,0,0,.5);backdrop-filter:blur(8px)}
.overlay.show{display:grid;animation:fadeIn .22s ease}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
.dialog{width:min(440px,calc(100vw - 30px));padding:20px;border-radius:var(--radius-lg);background:rgba(var(--surface-rgb),.96);border:1px solid var(--line-2);box-shadow:0 30px 90px rgba(0,0,0,.6);backdrop-filter:blur(20px);animation:slideUp .28s cubic-bezier(.2,.9,.3,1.2)}
@keyframes slideUp{from{transform:translateY(20px) scale(.96);opacity:0}to{transform:translateY(0) scale(1);opacity:1}}
.dialog h3{margin:0 0 14px;font-size:14.5px;font-weight:600}
.dialog input{width:100%;height:38px;padding:0 12px;border-radius:var(--radius-sm);background:rgba(0,0,0,.35);border:1px solid var(--line);color:#fff;outline:none;font-size:12.5px;transition:.2s}
.dialog input:focus{border-color:rgba(var(--accent-rgb),.4);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.08)}
.dialog-actions{display:flex;justify-content:flex-end;gap:7px;margin-top:16px}

.settings-modal{width:min(540px,calc(100vw - 30px));max-height:calc(100vh - 40px);display:flex;flex-direction:column;border-radius:var(--radius-lg);background:rgba(var(--surface-rgb),.97);border:1px solid var(--line-2);box-shadow:0 30px 90px rgba(0,0,0,.6);overflow:hidden;backdrop-filter:blur(20px);animation:slideUp .28s cubic-bezier(.2,.9,.3,1.2)}
.settings-head{display:flex;align-items:center;gap:10px;padding:14px 18px;border-bottom:1px solid var(--line)}
.settings-title{flex:1;font-size:14.5px;font-weight:600}
.settings-body{padding:18px;display:flex;flex-direction:column;gap:16px;overflow:auto}
.setting-item{display:flex;flex-direction:column;gap:8px}
.setting-label{font-size:11px;text-transform:uppercase;letter-spacing:.12em;color:var(--muted);font-weight:700}
.setting-select{background:rgba(0,0,0,.35);color:var(--text);border:1px solid var(--line);border-radius:var(--radius-sm);padding:9px 12px;outline:none;font:inherit;font-size:13px;cursor:pointer;transition:.2s}
.setting-select:hover{border-color:var(--line-2)}
.setting-select:focus{border-color:rgba(var(--accent-rgb),.4);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.08)}
.setting-select option{background:#0e1420;color:var(--text)}
.bg-row{display:flex;gap:8px;flex-wrap:wrap}
.bat-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.bat-current{padding:8px 12px;border-radius:var(--radius-sm);background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.2);color:#c1ffdd;font-family:var(--font-mono);font-size:12px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.bg-preview{width:100%;height:110px;border-radius:var(--radius-md);border:1px dashed var(--line-2);background:rgba(0,0,0,.25);display:grid;place-items:center;background-size:cover;background-position:center;font-size:11px;color:var(--muted-2);overflow:hidden;transition:.2s}
.bg-preview.has-img{border-style:solid;border-color:var(--line)}
.slider-row{display:flex;align-items:center;gap:12px}
.slider-row input[type=range]{flex:1;accent-color:var(--green);height:4px}
.slider-val{min-width:46px;text-align:right;font-variant-numeric:tabular-nums;color:var(--green);font-size:12px;font-weight:600}
.switch{display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none}
.switch input{display:none}
.switch-track{width:38px;height:22px;border-radius:999px;background:rgba(255,255,255,.12);position:relative;transition:.22s}
.switch-track:before{content:"";position:absolute;top:2px;left:2px;width:18px;height:18px;border-radius:50%;background:#fff;transition:.22s cubic-bezier(.2,.9,.3,1.4)}
.switch input:checked + .switch-track{background:var(--green)}
.switch input:checked + .switch-track:before{transform:translateX(16px)}
.switch-label{font-size:12.5px;color:var(--text)}

.editor{position:fixed;inset:12px;z-index:30;display:none;flex-direction:column;border-radius:var(--radius-lg);overflow:hidden;background:rgba(10,16,24,.97);border:1px solid var(--line-2);box-shadow:0 30px 100px rgba(0,0,0,.7);backdrop-filter:blur(20px)}
.editor.show{display:flex;animation:editorIn .3s cubic-bezier(.2,.9,.3,1.2)}
@keyframes editorIn{from{opacity:0;transform:scale(.98)}to{opacity:1;transform:scale(1)}}
.editor-top{min-height:52px;display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid var(--line);flex-wrap:wrap}
.editor-path{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:11.5px var(--font-mono);color:#93a4ad;padding:0 4px}
.editor textarea{flex:1;resize:none;border:0;border-radius:0;padding:16px;font:12.5px/1.65 var(--font-mono);background:rgba(0,0,0,.22);user-select:text}

.toast-stack{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:80;display:flex;flex-direction:column-reverse;gap:10px;max-width:min(420px,calc(100vw - 32px));width:max-content;pointer-events:none;align-items:center}
.toast{pointer-events:auto;display:flex;align-items:center;gap:12px;padding:12px 16px;border-radius:var(--radius-md);background:rgba(var(--surface-rgb),var(--panel-opacity));border:1px solid rgba(var(--accent-rgb),.35);box-shadow:0 16px 50px rgba(0,0,0,.5),0 0 20px rgba(var(--accent-rgb),.15),0 0 0 1px rgba(var(--accent-rgb),.08);font-size:12.5px;color:#e2e9ec;min-width:260px;backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);animation:toastIn .35s cubic-bezier(.2,.9,.3,1.3)}
@keyframes toastIn{from{opacity:0;transform:translateY(20px) scale(.94)}to{opacity:1;transform:translateY(0) scale(1)}}
.toast.leaving{animation:toastOut .28s ease forwards}
@keyframes toastOut{to{opacity:0;transform:translateY(20px) scale(.94)}}
.toast-icon{width:24px;height:24px;flex-shrink:0;display:grid;place-items:center;border-radius:50%;background:rgba(var(--accent-rgb),.15);color:var(--green);transition:.2s}
.toast-icon svg{width:14px;height:14px;stroke-width:2.4;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke:currentColor}
.toast.error{border-color:rgba(255,115,115,.5);box-shadow:0 16px 50px rgba(0,0,0,.5),0 0 20px rgba(255,115,115,.15)}
.toast.error .toast-icon{background:rgba(255,115,115,.15);color:var(--red)}
.toast.warning{border-color:rgba(255,209,102,.5);box-shadow:0 16px 50px rgba(0,0,0,.5),0 0 20px rgba(255,209,102,.15)}
.toast.warning .toast-icon{background:rgba(255,209,102,.15);color:var(--yellow)}
.toast.success{border-color:rgba(var(--accent-rgb),.5)}
.toast.success .toast-icon{background:rgba(var(--accent-rgb),.15);color:var(--green)}
.toast.info{border-color:rgba(121,169,255,.4);box-shadow:0 16px 50px rgba(0,0,0,.5),0 0 20px rgba(121,169,255,.15)}
.toast.info .toast-icon{background:rgba(121,169,255,.15);color:var(--blue)}
.toast-text{flex:1;line-height:1.4;word-break:break-word}
.toast-close{width:22px;height:22px;flex-shrink:0;border-radius:6px;background:transparent;color:#6c7c86;display:grid;place-items:center;transition:.15s;font-size:14px;line-height:1}
.toast-close:hover{background:rgba(255,255,255,.08);color:#fff}

.files-toggle{display:none;height:34px;padding:0 11px;border-radius:var(--radius-sm);background:rgba(255,255,255,.03);border:1px solid var(--line);color:#b8c4ce;font-size:12px;align-items:center;gap:6px}
.files-toggle:hover{background:rgba(255,255,255,.08)}

@media (max-width:1200px){
  .brand{max-width:200px}
  .metric.ram-metric{display:none}
}
@media (max-width:980px){
  .main{grid-template-columns:1fr}
  .files{position:fixed;top:12px;right:12px;bottom:12px;width:min(420px,calc(100vw - 24px));z-index:25;display:none;box-shadow:0 30px 80px rgba(0,0,0,.7)}
  .files.open{display:flex;animation:slideLeft .25s ease}
  @keyframes slideLeft{from{transform:translateX(20px);opacity:0}to{transform:translateX(0);opacity:1}}
  .files-toggle{display:inline-flex}
  .brand{max-width:160px}
}
@media (max-width:720px){
  .app{padding:8px;gap:8px}
  .header{padding:10px;gap:8px}
  .brand{border-right:0;padding-right:0;max-width:none;flex:1;min-width:140px}
  .title{font-size:13px}
  .metric.pid-metric{display:none}
  .actions{width:100%;justify-content:flex-start}
  .traffic{order:1}
  .server-pill{order:2}
  .metrics{order:4;flex:1}
  .metric{min-width:0;flex:1;padding:6px 8px}
  .btn{height:32px;padding:0 10px;font-size:11.5px}
  .drag-zone{display:none}
  .toast-stack{bottom:14px;max-width:calc(100vw - 20px)}
  .toast{min-width:0;width:100%}
}
@media (max-width:460px){
  .metric.cpu-metric{display:none}
  .subtitle{display:none}
}
</style>
</head>
<body>
<div class="bg-overlay"></div>
<div class="app">
  <header class="header glass">
    <div class="traffic">
      <button class="tl close" id="winClose" title="Close">
        <svg viewBox="0 0 8 8"><path d="M2 2l4 4M6 2l-4 4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>
      </button>
      <button class="tl min" id="winMin" title="Minimize">
        <svg viewBox="0 0 8 8"><path d="M2 4h4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>
      </button>
      <button class="tl max" id="winMax" title="Fullscreen (Alt — maximize)">
        <svg viewBox="0 0 8 8"><path d="M2.5 2.5l-1 3 3-1zM5.5 5.5l1-3-3 1z" fill="currentColor" stroke="none"/></svg>
      </button>
    </div>
    <div class="brand pywebview-drag-region">
      <div class="title">McPilot</div>
      <div class="subtitle" id="batFileLabel">—</div>
    </div>
    <div class="drag-zone pywebview-drag-region"></div>
    <div id="statusPill" class="server-pill"><div class="dot"></div><div id="statusText" class="server-text">Остановлен</div></div>
    <div class="metrics">
      <div class="metric cpu-metric"><div class="metric-label">CPU</div><div id="cpu" class="metric-value">0.0%</div></div>
      <div class="metric ram-metric"><div class="metric-label">RAM</div><div id="ram" class="metric-value">0.0 MB</div></div>
      <div class="metric pid-metric"><div class="metric-label">PID</div><div id="pid" class="metric-value">—</div></div>
    </div>
    <div class="spacer pywebview-drag-region"></div>
    <div class="actions">
      <button id="startBtn" class="btn primary" data-i18n="btn.start">Запустить</button>
      <button id="restartBtn" class="btn" data-i18n="btn.restart">Перезапуск</button>
      <button id="stopBtn" class="btn danger" data-i18n="btn.stop">Остановить</button>
      <button id="backupBtn" class="btn backup" data-i18n="btn.backup">Бэкап</button>
      <button id="filesToggle" class="files-toggle" data-i18n="btn.files">☰ Файлы</button>
      <button id="settingsBtn" class="gear" title="Настройки">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1.08-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
      </button>
    </div>
  </header>

  <main class="main">
    <section class="panel glass">
      <div class="panel-head">
        <div class="panel-title" data-i18n="panel.console">Консоль</div>
        <div class="spacer"></div>
        <div id="stateText" class="badge">READY</div>
      </div>
      <div id="console" class="console"></div>
      <div class="command">
        <span class="prompt">›</span>
        <input id="commandInput" data-i18n-placeholder="input.command" placeholder="Введите команду Minecraft..." autocomplete="off">
        <button id="sendBtn" class="send" data-i18n-title="btn.send" title="Отправить">
          <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        </button>
      </div>
    </section>

    <section class="panel glass files" id="filesPanel">
      <div class="panel-head">
        <div class="panel-title" data-i18n="panel.files">Файлы сервера</div>
        <div class="spacer"></div>
        <button id="filesClose" class="mini" title="Close" style="display:none">×</button>
      </div>
      <div class="file-toolbar">
        <button class="tool" id="newFile" data-i18n="tool.new_file">＋ Файл</button>
        <button class="tool" id="newFolder" data-i18n="tool.new_folder">＋ Папка</button>
        <button class="tool" id="upload" data-i18n="tool.upload">↑ Загрузить</button>
        <button class="tool red" id="deleteSelected" data-i18n="tool.delete">Удалить</button>
      </div>
      <div id="breadcrumbs" class="breadcrumbs"></div>
      <div id="fileList" class="file-list"></div>
    </section>
  </main>
</div>

<div id="contextMenu" class="context">
  <button data-action="open" data-i18n="ctx.open">Открыть</button>
  <button data-action="rename" data-i18n="ctx.rename">Переименовать</button>
  <button data-action="download" data-i18n="ctx.download">Скачать</button>
  <button data-action="delete" class="danger" data-i18n="ctx.delete">Удалить</button>
</div>

<div id="dialogOverlay" class="overlay">
  <div class="dialog">
    <h3 id="dialogTitle">Input</h3>
    <input id="dialogInput" autocomplete="off">
    <div class="dialog-actions">
      <button id="dialogCancel" class="btn" data-i18n="dialog.cancel">Отмена</button>
      <button id="dialogOk" class="btn primary" data-i18n="dialog.ok">OK</button>
    </div>
  </div>
</div>

<div id="settingsOverlay" class="overlay">
  <div class="settings-modal">
    <div class="settings-head">
      <div class="settings-title" data-i18n="settings.title">Настройки</div>
      <button class="mini" id="settingsClose">×</button>
    </div>
    <div class="settings-body">
      <div class="setting-item">
        <div class="setting-label" data-i18n="settings.lang">Язык</div>
        <select id="langSelect" class="setting-select">
          <option value="ru">Русский</option>
          <option value="en">English</option>
        </select>
      </div>
      <div class="setting-item">
        <div class="setting-label" data-i18n="settings.bat">Файл запуска</div>
        <div class="bat-row">
          <div class="bat-current" id="batCurrent">—</div>
          <button class="btn" id="pickBatBtn" data-i18n="settings.pick_bat">Выбрать</button>
        </div>
      </div>
      <div class="setting-item">
        <div class="setting-label" data-i18n="settings.theme">Тема</div>
        <select id="themeSelect" class="setting-select">
          <option value="emerald">Emerald</option>
          <option value="ocean">Ocean</option>
          <option value="cyber">Cyber</option>
          <option value="sunset">Sunset</option>
          <option value="rose">Rose</option>
          <option value="matrix">Matrix</option>
          <option value="gold">Gold</option>
          <option value="grey">Grey</option>
        </select>
      </div>
      <div class="setting-item">
        <div class="setting-label" data-i18n="settings.font">Шрифт интерфейса</div>
        <select id="fontSelect" class="setting-select">
          <option value="system">System</option>
          <option value="inter">Inter</option>
          <option value="roboto">Roboto</option>
          <option value="jetbrains">JetBrains Mono</option>
          <option value="fira">Fira Code</option>
          <option value="cascadia">Cascadia Code</option>
          <option value="consolas">Consolas</option>
          <option value="segoe">Segoe UI</option>
          <option value="serif">Source Serif</option>
          <option value="times">Times New Roman</option>
          <option value="comic">Comic Sans</option>
        </select>
      </div>
      <div class="setting-item">
        <div class="setting-label" data-i18n="settings.opacity">Прозрачность GUI</div>
        <div class="slider-row">
          <input type="range" id="opacitySlider" min="30" max="100" step="1" value="72">
          <span class="slider-val" id="opacityVal">72%</span>
        </div>
      </div>
      <div class="setting-item">
        <div class="setting-label" data-i18n="settings.sounds">Звуки</div>
        <label class="switch">
          <input type="checkbox" id="soundToggle" checked>
          <span class="switch-track"></span>
          <span class="switch-label" data-i18n="settings.sounds_enable">Включить уведомления</span>
        </label>
        <div class="slider-row">
          <span style="font-size:11px;color:var(--muted);min-width:60px" data-i18n="settings.volume">Громкость</span>
          <input type="range" id="volumeSlider" min="0" max="100" step="1" value="70">
          <span class="slider-val" id="volumeVal">70%</span>
        </div>
      </div>
      <div class="setting-item">
        <div class="setting-label" data-i18n="settings.background">Фон</div>
        <div class="bg-row">
          <button class="btn" id="pickBgBtn" data-i18n="settings.pick_bg">Выбрать фон</button>
          <button class="btn" id="resetBgBtn" data-i18n="settings.reset_bg">Сбросить</button>
        </div>
        <div id="bgPreview" class="bg-preview" data-i18n="settings.no_bg">Без фона</div>
      </div>
    </div>
  </div>
</div>

<div id="editor" class="editor">
  <div class="editor-top">
    <button id="editorClose" class="btn" data-i18n="dialog.close">Закрыть</button>
    <div id="editorPath" class="editor-path"></div>
    <button id="editorSave" class="btn primary" data-i18n="dialog.save">Сохранить</button>
  </div>
  <textarea id="editorText" spellcheck="false"></textarea>
</div>

<div id="toastStack" class="toast-stack"></div>

<script>
const $ = (id) => document.getElementById(id);
let currentPath = "";
let selectedPath = "";
let selectedType = "";
let editorPath = "";
let logCursor = 0;
let dialogResolver = null;
let busy = false;
let prevState = null;
let PLATFORM = { os: "windows" };

let SETTINGS = {
  lang: "ru", theme: "emerald", font: "system", background_file: null,
  gui_opacity: 0.72, sound_enabled: true, sound_volume: 0.7, bat_file: null,
};
let BG_URL = null;

const I18N = {
  ru: {
    "status.stopped":"Остановлен","status.running":"Сервер запущен","status.starting":"Запуск…",
    "status.stopping":"Остановка…","status.restarting":"Перезапуск…",
    "btn.start":"Запустить","btn.restart":"Перезапуск","btn.stop":"Остановить","btn.backup":"Бэкап",
    "btn.files":"☰ Файлы","btn.settings":"Настройки","btn.send":"Отправить",
    "panel.console":"Консоль","panel.files":"Файлы сервера",
    "input.command":"Введите команду Minecraft...",
    "tool.new_file":"＋ Файл","tool.new_folder":"＋ Папка","tool.upload":"↑ Загрузить","tool.delete":"Удалить",
    "ctx.open":"Открыть","ctx.rename":"Переименовать","ctx.download":"Скачать","ctx.delete":"Удалить",
    "dialog.cancel":"Отмена","dialog.ok":"OK","dialog.close":"Закрыть","dialog.save":"Сохранить",
    "settings.title":"Настройки","settings.lang":"Язык","settings.bat":"Файл запуска","settings.pick_bat":"Выбрать",
    "settings.theme":"Тема","settings.font":"Шрифт интерфейса","settings.opacity":"Прозрачность GUI",
    "settings.sounds":"Звуки","settings.sounds_enable":"Включить уведомления","settings.volume":"Громкость",
    "settings.background":"Фон","settings.pick_bg":"Выбрать фон","settings.reset_bg":"Сбросить","settings.no_bg":"Без фона",
    "toast.starting":"Сервер запускается…","toast.started":"Сервер запущен",
    "toast.stopping":"Сервер выключается…","toast.stopped":"Сервер выключен",
    "toast.restarting":"Перезапуск сервера…","toast.backup":"Бэкап создан",
    "toast.file_saved":"Файл успешно сохранён","toast.file_created":"Файл создан","toast.folder_created":"Папка создана",
    "toast.deleted":"Элемент удалён","toast.renamed":"Переименовано","toast.uploaded":"Файлы загружены",
    "toast.downloaded":"Файл сохранён на ПК","toast.bg_set":"Фон установлен","toast.bg_reset":"Фон сброшен",
    "toast.settings_saved":"Настройки сохранены","toast.language_changed":"Язык изменён",
    "toast.bat_changed":"Файл запуска изменён","toast.error":"Ошибка","toast.warning":"Внимание",
    "toast.select_first":"Сначала выбери элемент","toast.cannot_edit":"Файл нельзя открыть во встроенном редакторе",
    "toast.empty_command":"Введите команду",
    "confirm.delete":"Удалить {name}?","confirm.delete_sel":"Удалить выбранный элемент?",
    "dialog.new_file":"Новый файл","dialog.new_folder":"Новая папка","dialog.rename":"Переименовать",
    "server.root":"Сервер","files.empty":"Папка пуста","files.folder":"Папка"
  },
  en: {
    "status.stopped":"Stopped","status.running":"Server running","status.starting":"Starting…",
    "status.stopping":"Stopping…","status.restarting":"Restarting…",
    "btn.start":"Start","btn.restart":"Restart","btn.stop":"Stop","btn.backup":"Backup",
    "btn.files":"☰ Files","btn.settings":"Settings","btn.send":"Send",
    "panel.console":"Console","panel.files":"Server Files",
    "input.command":"Enter Minecraft command...",
    "tool.new_file":"＋ File","tool.new_folder":"＋ Folder","tool.upload":"↑ Upload","tool.delete":"Delete",
    "ctx.open":"Open","ctx.rename":"Rename","ctx.download":"Download","ctx.delete":"Delete",
    "dialog.cancel":"Cancel","dialog.ok":"OK","dialog.close":"Close","dialog.save":"Save",
    "settings.title":"Settings","settings.lang":"Language","settings.bat":"Startup file","settings.pick_bat":"Choose",
    "settings.theme":"Theme","settings.font":"Interface font","settings.opacity":"GUI opacity",
    "settings.sounds":"Sounds","settings.sounds_enable":"Enable notifications","settings.volume":"Volume",
    "settings.background":"Background","settings.pick_bg":"Choose image","settings.reset_bg":"Reset","settings.no_bg":"No background",
    "toast.starting":"Server is starting…","toast.started":"Server started",
    "toast.stopping":"Server is stopping…","toast.stopped":"Server stopped",
    "toast.restarting":"Restarting server…","toast.backup":"Backup created",
    "toast.file_saved":"File saved successfully","toast.file_created":"File created","toast.folder_created":"Folder created",
    "toast.deleted":"Item deleted","toast.renamed":"Renamed","toast.uploaded":"Files uploaded",
    "toast.downloaded":"File saved to PC","toast.bg_set":"Background applied","toast.bg_reset":"Background reset",
    "toast.settings_saved":"Settings saved","toast.language_changed":"Language changed",
    "toast.bat_changed":"Startup file changed","toast.error":"Error","toast.warning":"Warning",
    "toast.select_first":"Select an item first","toast.cannot_edit":"This file cannot be opened in the editor",
    "toast.empty_command":"Enter a command",
    "confirm.delete":"Delete {name}?","confirm.delete_sel":"Delete selected item?",
    "dialog.new_file":"New file","dialog.new_folder":"New folder","dialog.rename":"Rename",
    "server.root":"Server","files.empty":"Folder is empty","files.folder":"Folder"
  }
};

function t(key, vars){
  const dict = I18N[SETTINGS.lang] || I18N.ru;
  let text = dict[key] || I18N.ru[key] || key;
  if (vars) for (const k in vars) text = text.replace(`{${k}}`, vars[k]);
  return text;
}

function applyI18n(){
  document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => { el.placeholder = t(el.dataset.i18nPlaceholder); });
  document.querySelectorAll('[data-i18n-title]').forEach(el => { el.title = t(el.dataset.i18nTitle); });
  refreshStatusLabels();
}

let LAST_STATUS = { state: "stopped" };
function refreshStatusLabels(){
  const state = LAST_STATUS.state || "stopped";
  $('statusText').textContent = t("status." + state);
}

const THEMES = {
  emerald: { accent:"#5ee89a", rgb:"94,232,154",  glow1:"#1a6fff", glow2:"#00d890" },
  ocean:   { accent:"#5e9dff", rgb:"94,157,255",  glow1:"#0066ff", glow2:"#00c8ff" },
  cyber:   { accent:"#b46cff", rgb:"180,108,255", glow1:"#ff00c8", glow2:"#8000ff" },
  sunset:  { accent:"#ff9a5c", rgb:"255,154,92",  glow1:"#ff4040", glow2:"#ffaa00" },
  rose:    { accent:"#ff6b9d", rgb:"255,107,157", glow1:"#ff0066", glow2:"#ff70a6" },
  matrix:  { accent:"#39ff14", rgb:"57,255,20",   glow1:"#00ff41", glow2:"#003b00" },
  gold:    { accent:"#ffd166", rgb:"255,209,102", glow1:"#ff9500", glow2:"#ffcc00" },
  grey:    { accent:"#b8bcc4", rgb:"184,188,196", glow1:"#5a6270", glow2:"#3a4048" },
};

const FONTS = {
  system:    "'Inter',ui-sans-serif,system-ui,-apple-system,'Segoe UI',Roboto,sans-serif",
  inter:     "'Inter',system-ui,sans-serif",
  roboto:    "'Roboto','Helvetica Neue',Arial,sans-serif",
  jetbrains: "'JetBrains Mono','Cascadia Mono',ui-monospace,monospace",
  fira:      "'Fira Code',ui-monospace,monospace",
  cascadia:  "'Cascadia Code','Cascadia Mono',ui-monospace,Consolas,monospace",
  consolas:  "Consolas,'Courier New',monospace",
  segoe:     "'Segoe UI',Tahoma,Arial,sans-serif",
  serif:     "'Source Serif 4',Georgia,'Times New Roman',serif",
  times:     "'Times New Roman',Times,serif",
  comic:     "'Comic Sans MS','Comic Sans',cursive",
};

function applyTheme(name){
  const th = THEMES[name] || THEMES.emerald;
  const root = document.documentElement.style;
  root.setProperty('--green', th.accent);
  root.setProperty('--accent-rgb', th.rgb);
  root.setProperty('--glow-1', th.glow1);
  root.setProperty('--glow-2', th.glow2);
}
function applyFont(name){
  document.documentElement.style.setProperty('--font-ui', FONTS[name] || FONTS.system);
}
function applyOpacity(value){
  document.documentElement.style.setProperty('--panel-opacity', value.toFixed(2));
}
function applyBackground(url){
  if (url){
    document.body.style.backgroundImage = `url("${url}")`;
    document.body.classList.add('bg-custom');
    const prev = $('bgPreview');
    prev.style.backgroundImage = `url("${url}")`;
    prev.classList.add('has-img');
    prev.textContent = '';
  } else {
    document.body.style.backgroundImage = '';
    document.body.classList.remove('bg-custom');
    const prev = $('bgPreview');
    prev.style.backgroundImage = '';
    prev.classList.remove('has-img');
    prev.textContent = t('settings.no_bg');
  }
}

let audioCtx = null;
function getCtx(){
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === 'suspended') audioCtx.resume();
  return audioCtx;
}
function bell(freq, startOffset, duration, gain, decay){
  const c = getCtx();
  const t0 = c.currentTime + startOffset;
  const overtones = [
    { mult: 1, amp: 1.00 }, { mult: 2, amp: 0.30 },
    { mult: 3, amp: 0.12 }, { mult: 4, amp: 0.05 },
  ];
  const volume = SETTINGS.sound_volume || 0.7;
  for (const o of overtones){
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = 'sine';
    osc.frequency.value = freq * o.mult;
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(gain * o.amp * volume, t0 + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
    osc.connect(g).connect(c.destination);
    osc.start(t0);
    osc.stop(t0 + duration + 0.05);
  }
}
function playStartSound(){
  if (!SETTINGS.sound_enabled) return;
  bell(1046.50, 0.00, 0.30, 0.5, 8);
  bell(1318.51, 0.10, 0.30, 0.5, 8);
  bell(1567.98, 0.20, 0.50, 0.5, 6);
}
function playStopSound(){
  if (!SETTINGS.sound_enabled) return;
  bell(830.61, 0.00, 0.35, 0.55, 6.5);
  bell(587.33, 0.14, 0.50, 0.55, 6.0);
}
function hasStartupErrors(){
  const logs = document.querySelectorAll('.log');
  const recent = Array.from(logs).slice(-40);
  for (const el of recent) if (el.classList.contains('error')) return true;
  return false;
}

const TOAST_ICONS = {
  success: '<svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg>',
  error:   '<svg viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg>',
  warning: '<svg viewBox="0 0 24 24"><path d="M12 9v4M12 17h.01"/></svg>',
  info:    '<svg viewBox="0 0 24 24"><path d="M12 16v-4M12 8h.01"/></svg>',
};

function toast(message, type = 'info', duration = 3500){
  const stack = $('toastStack');
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.innerHTML = `
    <div class="toast-icon">${TOAST_ICONS[type] || TOAST_ICONS.info}</div>
    <div class="toast-text">${esc(message)}</div>
    <button class="toast-close" aria-label="Close">×</button>`;
  const close = () => {
    if (el.classList.contains('leaving')) return;
    el.classList.add('leaving');
    setTimeout(() => el.remove(), 280);
  };
  el.querySelector('.toast-close').onclick = close;
  stack.appendChild(el);
  while (stack.children.length > 3) stack.removeChild(stack.firstChild);
  if (duration > 0) setTimeout(close, duration);
}

function esc(v){
  return String(v)
    .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
    .replaceAll('"','&quot;').replaceAll("'",'&#039;');
}
function size(v){
  if(!v) return '';
  if(v<1024) return v+' B';
  if(v<1048576) return (v/1024).toFixed(1)+' KB';
  if(v<1073741824) return (v/1048576).toFixed(1)+' MB';
  return (v/1073741824).toFixed(1)+' GB';
}

document.addEventListener('click', e => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const rect = btn.getBoundingClientRect();
  const sz = Math.max(rect.width, rect.height);
  const ripple = document.createElement('span');
  ripple.className = 'ripple';
  ripple.style.width = ripple.style.height = sz + 'px';
  ripple.style.left = (e.clientX - rect.left - sz / 2) + 'px';
  ripple.style.top = (e.clientY - rect.top - sz / 2) + 'px';
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
});

const SVG_ICONS = {
  folder:'<svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"/></svg>',
  java:'<svg viewBox="0 0 24 24"><path d="M8 21h8M12 3c-2 4-2 8 0 11 2 3 2 5 0 7"/></svg>',
  json:'<svg viewBox="0 0 24 24"><path d="M8 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h2M16 4h2a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-2M12 9v6"/></svg>',
  yaml:'<svg viewBox="0 0 24 24"><path d="M4 7h6M4 12h16M4 17h10"/></svg>',
  config:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9l-2.1 2.1M7 17l-2.1 2.1"/></svg>',
  text:'<svg viewBox="0 0 24 24"><path d="M6 4h8l4 4v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M14 4v4h4M8 13h8M8 17h5"/></svg>',
  log:'<svg viewBox="0 0 24 24"><path d="M6 4h8l4 4v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M14 4v4h4M8 12h8M8 16h8"/></svg>',
  terminal:'<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 10l3 3-3 3M12 17h6"/></svg>',
  js:'<svg viewBox="0 0 24 24"><path d="M6 4h8l4 4v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M14 4v4h4"/></svg>',
  css:'<svg viewBox="0 0 24 24"><path d="M6 4h8l4 4v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M14 4v4h4"/></svg>',
  html:'<svg viewBox="0 0 24 24"><path d="M6 4h8l4 4v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M14 4v4h4"/></svg>',
  archive:'<svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M10 4v6M14 4v6M10 15h4"/></svg>',
  image:'<svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2"/><circle cx="9" cy="9" r="1.5"/><path d="M4 17l4-4 4 4 3-3 5 5"/></svg>',
  database:'<svg viewBox="0 0 24 24"><ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/></svg>',
  file:'<svg viewBox="0 0 24 24"><path d="M6 4h8l4 4v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M14 4v4h4"/></svg>'
};
function iconHTML(type){
  const svg = SVG_ICONS[type] || SVG_ICONS.file;
  return `<div class="file-icon icon-${esc(type)}">${svg}</div>`;
}

function classifyLog(line){
  const l = line.toUpperCase();
  if (/\b(ERROR|SEVERE|EXCEPTION|FAILED|FATAL|CRASH)\b/.test(l) || /Exception|Caused by/.test(line)) return 'error';
  if (/\b(WARN|WARNING)\b/.test(l)) return 'warn';
  if (/Done \(/.test(l) || /Server started|Starting minecraft server/.test(l)) return 'ok';
  if (/\[Manager\]/.test(l)) return 'info';
  return '';
}

function setServerUI(s){
  LAST_STATUS = s || {};
  const pill = $('statusPill');
  pill.className = 'server-pill ' + (s.state || '');
  $('pid').textContent = s.pid ? String(s.pid) : '—';
  refreshStatusLabels();
  const state = s.state || 'stopped';
  $('stateText').textContent = state.toUpperCase();
  $('stateText').className = 'badge ' + (state === 'running' ? 'running' : '');
  $('startBtn').disabled = !!s.operation || ['running','starting','restarting'].includes(state);
  $('restartBtn').disabled = !!s.operation || state === 'starting' || state === 'stopping';
  $('stopBtn').disabled = !!s.operation || !s.running;
}

async function refreshStatus(){
  try{
    const s = await pywebview.api.status();
    const newState = s.state || 'stopped';
    if (prevState !== null && prevState !== newState){
      if (prevState === 'starting' && newState === 'running'){
        if (!hasStartupErrors()){
          playStartSound();
          toast(t('toast.started'), 'success');
        }
      }
      if (prevState === 'running' && newState === 'stopping') toast(t('toast.stopping'), 'info');
      if ((prevState === 'running' || prevState === 'stopping') && newState === 'stopped'){
        playStopSound();
        toast(t('toast.stopped'), 'warning');
      }
      if (prevState === 'starting' && newState === 'stopped') toast(t('toast.error'), 'error');
    }
    prevState = newState;
    setServerUI(s);
  }catch(e){}
}
async function refreshResources(){
  try{
    const r = await pywebview.api.get_resources();
    $('cpu').textContent = Number(r.cpu||0).toFixed(1) + '%';
    $('ram').textContent = Number(r.ram||0).toFixed(1) + ' MB';
  }catch(e){}
}
async function pollLogs(){
  try{
    const r = await pywebview.api.logs(logCursor);
    const box = $('console');
    const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
    for (const line of r.items){
      const d = document.createElement('div');
      const cls = classifyLog(line);
      d.className = 'log' + (cls ? ' ' + cls : '');
      d.textContent = line;
      box.appendChild(d);
    }
    logCursor = r.next;
    while (box.children.length > 6000) box.removeChild(box.firstChild);
    if (nearBottom) box.scrollTop = box.scrollHeight;
  }catch(e){}
}

$('startBtn').onclick = async()=>{
  if (busy) return; busy = true;
  try {
    const r = await pywebview.api.start_server();
    if (r.success) toast(t('toast.starting'), 'info');
    else toast(r.message || t('toast.error'), 'error');
  } finally { busy = false; await refreshStatus(); }
};
$('stopBtn').onclick = async()=>{
  if (busy) return; busy = true;
  try {
    const r = await pywebview.api.stop_server();
    if (r.success) toast(t('toast.stopping'), 'info');
    else toast(r.message || t('toast.error'), 'error');
  } finally { busy = false; await refreshStatus(); }
};
$('restartBtn').onclick = async()=>{
  if (busy) return; busy = true;
  try {
    const r = await pywebview.api.restart_server();
    if (r.success) toast(t('toast.restarting'), 'info');
    else toast(r.message || t('toast.error'), 'error');
  } finally { busy = false; await refreshStatus(); }
};
$('backupBtn').onclick = async()=>{
  const r = await pywebview.api.backup(currentPath);
  toast(r.message || t('toast.backup'), r.success ? 'success' : 'error');
};

async function send(){
  const v = $('commandInput').value.trim();
  if (!v){ toast(t('toast.empty_command'), 'warning'); return; }
  const r = await pywebview.api.send_command(v);
  if (!r.success) toast(r.message, 'error');
  $('commandInput').value = '';
  $('commandInput').focus();
}
$('sendBtn').onclick = send;
$('commandInput').onkeydown = e=>{ if (e.key === 'Enter'){ e.preventDefault(); send(); } };

function renderCrumbs(path){
  const box = $('breadcrumbs');
  box.innerHTML = '';
  const root = document.createElement('button');
  root.className = 'crumb';
  root.textContent = t('server.root');
  root.onclick = () => loadFiles('');
  box.appendChild(root);
  const parts = path.split('/').filter(Boolean);
  let built = '';
  parts.forEach(p => {
    const sep = document.createElement('span');
    sep.className = 'sep';
    sep.textContent = '›';
    box.appendChild(sep);
    built = built ? (built + '/' + p) : p;
    const b = document.createElement('button');
    b.className = 'crumb';
    b.textContent = p;
    const target = built;
    b.onclick = () => loadFiles(target);
    box.appendChild(b);
  });
}

async function loadFiles(path = currentPath){
  const r = await pywebview.api.list_files(path);
  if (!r.success){ toast(r.message, 'error'); return; }
  currentPath = r.data.path;
  selectedPath = '';
  selectedType = '';
  renderCrumbs(currentPath);
  const list = $('fileList');
  list.innerHTML = '';
  if (r.data.items.length === 0){
    list.innerHTML = `<div class="empty">${t('files.empty')}</div>`;
    return;
  }
  let idx = 0;
  for (const item of r.data.items){
    const row = document.createElement('div');
    row.className = 'file-row';
    row.style.animationDelay = (idx++ * 0.015) + 's';
    row.dataset.path = item.path;
    row.dataset.type = item.type;
    row.innerHTML = `
      ${iconHTML(item.icon)}
      <div class="file-name">${esc(item.name)}</div>
      <div class="file-meta">${item.type==='file'?size(item.size):t('files.folder')}</div>
      <div class="row-actions">
        <button class="mini" title="${t('ctx.rename')}">✎</button>
        <button class="mini" title="${t('ctx.download')}">↓</button>
        <button class="mini" title="${t('ctx.delete')}">×</button>
      </div>`;
    row.addEventListener('click', async e => {
      e.stopPropagation();
      selectedPath = item.path;
      selectedType = item.type;
      document.querySelectorAll('.file-row').forEach(x => x.classList.remove('selected'));
      row.classList.add('selected');
      if (e.target.closest('.mini')) return;
      if (item.type === 'directory') await loadFiles(item.path);
      else if (item.editable) await openEditor(item.path);
      else toast(t('toast.cannot_edit'), 'warning');
    });
    row.addEventListener('contextmenu', e => {
      e.preventDefault();
      selectedPath = item.path;
      selectedType = item.type;
      showContext(e.clientX, e.clientY);
      document.querySelectorAll('.file-row').forEach(x => x.classList.remove('selected'));
      row.classList.add('selected');
    });
    const buttons = row.querySelectorAll('.mini');
    buttons[0].onclick = async e => {
      e.stopPropagation();
      const n = await ask(t('dialog.rename'), item.name);
      if (n){
        const r = await pywebview.api.rename(item.path, n);
        if (r.success) { toast(t('toast.renamed'), 'success'); loadFiles(currentPath); }
        else toast(r.message, 'error');
      }
    };
    buttons[1].onclick = async e => {
      e.stopPropagation();
      const r = await pywebview.api.download(item.path);
      if (r.success) toast(t('toast.downloaded'), 'success');
      else if (!r.cancelled) toast(r.message, 'error');
    };
    buttons[2].onclick = async e => {
      e.stopPropagation();
      if (confirm(t('confirm.delete', { name: item.name }))){
        const r = await pywebview.api.delete(item.path);
        if (r.success) { toast(t('toast.deleted'), 'success'); loadFiles(currentPath); }
        else toast(r.message, 'error');
      }
    };
    list.appendChild(row);
  }
}

function showContext(x, y){
  const m = $('contextMenu');
  m.style.display = 'block';
  m.style.left = Math.min(x, window.innerWidth - 200) + 'px';
  m.style.top = Math.min(y, window.innerHeight - 180) + 'px';
}
document.addEventListener('click', () => { $('contextMenu').style.display = 'none'; });
$('contextMenu').onclick = async e => {
  const action = e.target.dataset.action;
  if (!action || !selectedPath) return;
  $('contextMenu').style.display = 'none';
  if (action === 'open'){
    if (selectedType === 'directory') loadFiles(selectedPath);
    else openEditor(selectedPath);
  }
  if (action === 'rename'){
    const n = await ask(t('dialog.rename'), selectedPath.split('/').pop());
    if (n){
      const r = await pywebview.api.rename(selectedPath, n);
      if (r.success) { toast(t('toast.renamed'), 'success'); loadFiles(currentPath); }
      else toast(r.message, 'error');
    }
  }
  if (action === 'download'){
    const r = await pywebview.api.download(selectedPath);
    if (r.success) toast(t('toast.downloaded'), 'success');
    else if (!r.cancelled) toast(r.message, 'error');
  }
  if (action === 'delete'){
    if (confirm(t('confirm.delete_sel'))){
      const r = await pywebview.api.delete(selectedPath);
      if (r.success) { toast(t('toast.deleted'), 'success'); loadFiles(currentPath); }
      else toast(r.message, 'error');
    }
  }
};

function ask(title, value = ''){
  return new Promise(resolve => {
    dialogResolver = resolve;
    $('dialogTitle').textContent = title;
    $('dialogInput').value = value;
    $('dialogOverlay').classList.add('show');
    setTimeout(() => { $('dialogInput').focus(); $('dialogInput').select(); }, 30);
  });
}
function closeAsk(v){
  $('dialogOverlay').classList.remove('show');
  if (dialogResolver){ dialogResolver(v); dialogResolver = null; }
}
$('dialogOk').onclick = () => closeAsk($('dialogInput').value.trim() || null);
$('dialogCancel').onclick = () => closeAsk(null);
$('dialogInput').onkeydown = e => {
  if (e.key === 'Enter') closeAsk($('dialogInput').value.trim() || null);
  if (e.key === 'Escape') closeAsk(null);
};

$('newFile').onclick = async () => {
  const n = await ask(t('dialog.new_file'), 'server.txt');
  if (n){
    const r = await pywebview.api.create_file(currentPath, n);
    if (r.success) { toast(t('toast.file_created'), 'success'); loadFiles(currentPath); }
    else toast(r.message, 'error');
  }
};
$('newFolder').onclick = async () => {
  const n = await ask(t('dialog.new_folder'), 'new_folder');
  if (n){
    const r = await pywebview.api.create_folder(currentPath, n);
    if (r.success) { toast(t('toast.folder_created'), 'success'); loadFiles(currentPath); }
    else toast(r.message, 'error');
  }
};
$('upload').onclick = async () => {
  const r = await pywebview.api.upload(currentPath);
  if (r.success) { toast(t('toast.uploaded'), 'success'); loadFiles(currentPath); }
  else if (!r.cancelled) toast(r.message, 'error');
};
$('deleteSelected').onclick = async () => {
  if (!selectedPath){ toast(t('toast.select_first'), 'warning'); return; }
  if (confirm(t('confirm.delete_sel'))){
    const r = await pywebview.api.delete(selectedPath);
    if (r.success){ toast(t('toast.deleted'), 'success'); selectedPath = ''; loadFiles(currentPath); }
    else toast(r.message, 'error');
  }
};

async function openEditor(path){
  const r = await pywebview.api.read_file(path);
  if (!r.success){ toast(r.message, 'error'); return; }
  editorPath = path;
  $('editorPath').textContent = path;
  $('editorText').value = r.data.content;
  $('editor').classList.add('show');
  setTimeout(() => $('editorText').focus(), 30);
}
$('editorClose').onclick = () => { $('editor').classList.remove('show'); editorPath = ''; };
$('editorSave').onclick = async () => {
  const r = await pywebview.api.save_file(editorPath, $('editorText').value);
  if (r.success) toast(t('toast.file_saved'), 'success');
  else toast(r.message, 'error');
};
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 's' && $('editor').classList.contains('show')){
    e.preventDefault();
    $('editorSave').click();
  }
});

function openSettings(){
  $('langSelect').value = SETTINGS.lang || 'ru';
  $('themeSelect').value = SETTINGS.theme || 'emerald';
  $('fontSelect').value = SETTINGS.font || 'system';
  const op = Math.round((SETTINGS.gui_opacity || 0.72) * 100);
  $('opacitySlider').value = op;
  $('opacityVal').textContent = op + '%';
  $('soundToggle').checked = !!SETTINGS.sound_enabled;
  const vol = Math.round((SETTINGS.sound_volume || 0.7) * 100);
  $('volumeSlider').value = vol;
  $('volumeVal').textContent = vol + '%';
  $('batCurrent').textContent = SETTINGS.bat_file || '—';
  $('settingsOverlay').classList.add('show');
}
$('settingsBtn').onclick = openSettings;
$('settingsClose').onclick = () => $('settingsOverlay').classList.remove('show');
$('settingsOverlay').onclick = e => { if (e.target === $('settingsOverlay')) $('settingsOverlay').classList.remove('show'); };

$('langSelect').onchange = async e => {
  SETTINGS.lang = e.target.value;
  applyI18n();
  await pywebview.api.update_settings({ lang: SETTINGS.lang });
  toast(t('toast.language_changed'), 'success');
};
$('themeSelect').onchange = async e => {
  SETTINGS.theme = e.target.value;
  applyTheme(SETTINGS.theme);
  await pywebview.api.update_settings({ theme: SETTINGS.theme });
  toast(t('toast.settings_saved'), 'success');
};
$('fontSelect').onchange = async e => {
  SETTINGS.font = e.target.value;
  applyFont(SETTINGS.font);
  await pywebview.api.update_settings({ font: SETTINGS.font });
};
$('opacitySlider').oninput = e => {
  const v = e.target.value / 100;
  $('opacityVal').textContent = e.target.value + '%';
  applyOpacity(v);
};
$('opacitySlider').onchange = async e => {
  const v = e.target.value / 100;
  SETTINGS.gui_opacity = v;
  await pywebview.api.update_settings({ gui_opacity: v });
};
$('soundToggle').onchange = async e => {
  SETTINGS.sound_enabled = e.target.checked;
  await pywebview.api.update_settings({ sound_enabled: SETTINGS.sound_enabled });
  if (SETTINGS.sound_enabled) playStartSound();
};
$('volumeSlider').oninput = e => {
  $('volumeVal').textContent = e.target.value + '%';
  SETTINGS.sound_volume = e.target.value / 100;
};
$('volumeSlider').onchange = async e => {
  SETTINGS.sound_volume = e.target.value / 100;
  await pywebview.api.update_settings({ sound_volume: SETTINGS.sound_volume });
  playStartSound();
};
$('pickBgBtn').onclick = async () => {
  const r = await pywebview.api.pick_background();
  if (r.cancelled) return;
  if (!r.success){ toast(r.message, 'error'); return; }
  BG_URL = r.data_url;
  SETTINGS = r.settings;
  applyBackground(BG_URL);
  toast(t('toast.bg_set'), 'success');
};
$('resetBgBtn').onclick = async () => {
  const r = await pywebview.api.reset_background();
  if (r.success){
    BG_URL = null;
    applyBackground(null);
    SETTINGS.background_file = null;
    toast(t('toast.bg_reset'), 'info');
  }
};
$('pickBatBtn').onclick = async () => {
  const r = await pywebview.api.pick_bat_file();
  if (r.cancelled) return;
  if (!r.success){ toast(r.message, 'error'); return; }
  SETTINGS.bat_file = r.bat_file;
  $('batCurrent').textContent = r.bat_file;
  $('batFileLabel').textContent = r.bat_file;
  toast(t('toast.bat_changed'), 'success');
};

$('winClose').onclick = async()=>{ try{ await pywebview.api.close_window(); }catch(e){} };
$('winMin').onclick = async()=>{ try{ await pywebview.api.minimize_window(); }catch(e){} };
$('winMax').onclick = async e => {
  try{
    if (e.altKey) await pywebview.api.maximize_window();
    else await pywebview.api.toggle_fullscreen();
  }catch(err){}
};

function isNarrow(){ return window.matchMedia('(max-width:980px)').matches; }
$('filesToggle').onclick = () => {
  const panel = $('filesPanel');
  panel.classList.toggle('open');
  $('filesClose').style.display = panel.classList.contains('open') ? 'grid' : 'none';
};
$('filesClose').onclick = () => {
  $('filesPanel').classList.remove('open');
  $('filesClose').style.display = 'none';
};
window.addEventListener('resize', () => {
  if (!isNarrow()){
    $('filesPanel').classList.remove('open');
    $('filesClose').style.display = 'none';
  }
});

window.addEventListener('pywebviewready', async () => {
  try{
    const s = await pywebview.api.get_settings();
    if (s.success){
      SETTINGS = s.settings || SETTINGS;
      BG_URL = s.background || null;
      PLATFORM = s.platform || PLATFORM;
    }
  }catch(e){}

  applyTheme(SETTINGS.theme || 'emerald');
  applyFont(SETTINGS.font || 'system');
  applyOpacity(SETTINGS.gui_opacity || 0.72);
  applyBackground(BG_URL);
  applyI18n();

  try{
    const b = await pywebview.api.get_bat_file();
    $('batFileLabel').textContent = b.bat_file || '—';
    $('batCurrent').textContent = b.bat_file || '—';
    document.title = 'McPilot — ' + (b.bat_file || '');
  }catch(e){}

  await loadFiles('');
  await pollLogs();
  await refreshStatus();
  await refreshResources();
  setInterval(refreshStatus, 700);
  setInterval(refreshResources, 1000);
  setInterval(pollLogs, 500);
  $('commandInput').focus();
});
</script>
</body>
</html>
'''


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------


def main():
    if relaunch_in_new_console():
        sys.exit(0)

    setup_console()
    show_banner()

    settings = load_settings()
    bat_file = settings.get("bat_file")
    if not bat_file or not (APP_DIR / bat_file).exists():
        bat_file = ask_for_bat_file(lang=settings.get("lang", "ru"), current=None)
        settings["bat_file"] = bat_file
        save_settings(settings)
    else:
        print(f"  Startup file: {bat_file}")
        print("  (Change it in Settings)")
        print()

    manager = MinecraftManager(bat_file)
    files = FileManager(APP_DIR)
    api = API(manager, files)

    window = webview.create_window(
        APP_NAME,
        html=HTML,
        js_api=api,
        width=1400,
        height=860,
        min_size=(420, 520),
        background_color="#080b11",
        text_select=True,
        frameless=True,
        easy_drag=False,
        shadow=True,
    )

    try:
        webview.start(debug=False)
    finally:
        manager.shutdown()


if __name__ == "__main__":
    main()